using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Rendering.VirtualTexturing;
using UnityEngine.ResourceManagement.AsyncOperations;

public static class SkillFactory
{
    public static async UniTask<List<SkillInstance>> CreateSkill(List<string> skillNames)
    {
        //현업에서 쓰는 데이터 로딩 방식
        //어드레서블 시스템 -> 패치 시스템
        List<SkillData> result = new List<SkillData>();

        foreach (var skillName in skillNames)
        {
            var handle = Addressables.LoadAssetAsync<SkillData>($"Assets/SkillData/{skillName}.asset");
            await handle.Task;

            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                result.Add(handle.Result);
                
                Debug.Log($"Skill {skillName} has been created");
            }
            else
            {
                Debug.LogError($"Failed to load skill {skillName}");
            }
        }

        List<SkillInstance> skills = new List<SkillInstance>();
        
        foreach (var skillData in result)
        {
            var go = new GameObject(skillData.skillName);
            SkillInstance instance = go.AddComponent<SkillInstance>();
            skills.Add(instance);
        }

        return skills;
        //return new List<SkillData>();
    }
}
