using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class SkillCooltimer : MonoBehaviour
{
    public SkillData skillData;

    private float remainDuration;

    public bool IsReady => 0 >= remainDuration;

    public void StartCoolTimer()
    {
        CooltimeProcess();
    }

    async void CooltimeProcess()
    {
        remainDuration = skillData.skillCooltime;
        
        while (remainDuration > 0)
        {
            remainDuration -= Time.deltaTime;
            
            await UniTask.Yield();
        }
    }
}
