using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SkillData", menuName = "Game/Skill Data")]
public class SkillData : ScriptableObject
{
    //ScriptableObject는 public이 좋음
    public string skillName;
    public string skillIcon;
    public string skillAnimation;
    public string skillDuration;
    
    public float skillCooltime;
    public float skillEnableDistance;
}
