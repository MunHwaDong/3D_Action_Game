using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//컴포넌트가 클래스보다 비싸다.
[RequireComponent(typeof(SkillCooltimer))]
public class SkillInstance : MonoBehaviour
{
    public SkillData skillData;
    private SkillCooltimer skillCooltimer;

    void Start()
    {
        skillCooltimer.skillData = skillData;
    }

    public void FireSkill()
    {
        skillCooltimer.StartCoolTimer();
    }

    public bool CanFireSkill()
    {
        return skillCooltimer.IsReady;
    }
}
