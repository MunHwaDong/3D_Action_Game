using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using UnityEngine;

public class SkillController : MonoBehaviour
{
    private List<SkillInstance> skillInstances = new List<SkillInstance>();
    public List<string> skillDataNames = new List<string>();

    async void Start()
    {
        var result = await SkillFactory.CreateSkill(new List<string>() { "Skill1", "Skill2", "Skill3" });
    }
}
