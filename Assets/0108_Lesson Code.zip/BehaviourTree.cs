using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BehaviourTree : MonoBehaviour
{
    private Node _root;

    void Start()
    {
        _root = CreateBehaviourTree();
    }

    private Node CreateBehaviourTree()
    {
        Selector root = new Selector();
        
        Sequence chaseSequence = new Sequence();
        chaseSequence.AddChild(new ActionNode(CheckPlayerVisibility));
        chaseSequence.AddChild(new ActionNode(ChasePlayer));

        ActionNode patrolAction = new ActionNode(Patrol);
        
        root.AddChild(chaseSequence);
        root.AddChild(patrolAction);

        return root;
    }

    private NodeState CheckPlayerVisibility()
    {
        bool playerVisible = Vector3.Distance(transform.position, Player.Instance.transform.position) < 10;
        return playerVisible ? NodeState.Success : NodeState.Failure;
    }

    private NodeState ChasePlayer()
    {
        transform.position = Vector3.MoveTowards(transform.position, Player.Instance.transform.position, Time.deltaTime * 5);
        return NodeState.Running;
    }

    private NodeState Patrol()
    {
        // 정해진 경로를 따라 순찰
        Debug.Log("Patrolling...");
        return NodeState.Running;
    }
}
