using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DamageHandler
{
    protected DamageHandler nextHandler;

    public void SetNextHandler(DamageHandler handler)
    {
        this.nextHandler = handler;
    }
    
    public abstract float HandleDamage(float damage, MonsterStatus monsterStatus);
}

public class DamageCalculation_Ver1 : DamageHandler
{
    public override float HandleDamage(float damage, MonsterStatus monsterStatus)
    {
        damage += 100.0f;
        return nextHandler?.HandleDamage(damage, monsterStatus) ?? damage;
    }
}

public class DamageCalculation_Ver2 : DamageHandler
{
    public override float HandleDamage(float damage, MonsterStatus monsterStatus)
    {
        damage *= 0.3f;
        return nextHandler?.HandleDamage(damage, monsterStatus) ?? damage;
    }
}

