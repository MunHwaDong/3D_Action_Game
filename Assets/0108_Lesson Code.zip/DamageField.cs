using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

//For Builder Pattern
public class DamageField : MonoBehaviour
{
    public float damage;
    public float radius;
    public float duration;
    public float tickInterval;
    public Vector3 position;
    
    public DamageHandler damageHandler;

    // public float GetCalculateDamage()
    // {
    //     if (damageHandler != null)
    //     {
    //         return damageHandler.HandleDamage(damage);
    //     }
    //     else
    //     {
    //         return damage;
    //     }
    // }
}

public class DamageFieldBuilder
{
    private DamageField damageField;

    public DamageFieldBuilder()
    {
        damageField = new GameObject("DamageField").AddComponent<DamageField>();
        damageField.AddComponent<SphereCollider>();
    }
    
    //Builder의 특징 1. 자기 자신을 반환한다.
    public DamageFieldBuilder SetDamage(float damage)
    {
        damageField.damage = damage;
        return this;
    }

    public DamageFieldBuilder SetRadius(float radius)
    {
        damageField.GetComponent<SphereCollider>().radius = radius;
        damageField.GetComponent<SphereCollider>().isTrigger = true;
        
        damageField.radius = radius;
        return this;
    }

    public DamageFieldBuilder SetDuration(float duration)
    {
        damageField.duration = duration;
        return this;
    }

    public DamageFieldBuilder SetTickInterval(float tickInterval)
    {
        damageField.tickInterval = tickInterval;
        return this;
    }

    public DamageFieldBuilder SetPosition(Vector3 position)
    {
        damageField.transform.position = position;
        return this;
    }

    public DamageFieldBuilder SetDamageHandler(DamageHandler damageHandler)
    {
        if(damageField.damageHandler == null) damageField.damageHandler = damageHandler;
        else
        {
            damageField.damageHandler.SetNextHandler(damageHandler);
        }
        
        return this;
    }

    //DamageField Class를 만드는 역할을 한다.
    public DamageField Build()
    {
        return damageField;
    }
}