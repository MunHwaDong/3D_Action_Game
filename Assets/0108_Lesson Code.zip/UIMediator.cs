using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IMediator
{
    void NotifyHealthChanged(float health);
}

public class UIMediator : MonoBehaviour, IMediator
{
    private MonsterStatus monsterStatus;
    
    public void NotifyHealthChanged(float health)
    {
        
    }
}
